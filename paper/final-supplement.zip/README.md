# Final manuscript alignment supplement

This supplement binds the final J0 manuscript to the unchanged public Lean source at commit `00d977912114c7fffb189e85051914685dcee5e6`. It covers 16 numbered results and 118 retained mathematical assertions. Proposition 5.1 explicitly requires a positive polar radius. `PolarAudit.lean` proves both directions of the polar/sector bridge and the full quantified conclusion, and checks the excluded zero-radius case.

The package includes the current 248-root type catalog, all 359 actual definition bodies, dependency closures, fresh full environment-reflection evidence, and independent statement/PDF reviews. The fixed 193-file code source archive is byte-identical to the published source. No manuscript TeX/PDF or external literature PDF is included.

## Verify

Keep the supplement outside the code checkout. Obtain the code from the public repository or extract `fixed-code-source.zip` into a separate folder. With a Git clone, check out the fixed commit above. Follow the fixed code README to fetch the pinned dependencies before verification; some definition evidence refers to their exact mathlib source files.

```
python3 verify_supplement.py --code-root /path/to/fixed-code
python3 verify_supplement.py --code-root /path/to/fixed-code --manuscript /private/path/to/main.tex
```

The default verification checks package hashes, source identity and included statement/type/definition evidence. Without a manuscript path it does not claim to re-read the complete TeX. It does not run Lean or modify files.

For live kernel replay, follow the fixed code README to obtain its pinned Lean/dependencies, then run from the code directory:

```
python3 check.py
lake env lean /path/to/supplement/PolarAudit.lean
lake env lean /path/to/supplement/DefinitionAudit.lean
```

`check.py` checks the fixed code's 16 quantified targets, supporting targets and transitive axioms. The supplement's new reflection and six audit checks are recorded separately from the inherited historical clean rebuild. The current statement correspondence is a reviewed mathematical mapping; a successful kernel run alone does not replace that semantic review.

## Provenance

`provenance-index.json` distinguishes exact copies, path-normalized derivatives, and historical hash-only inputs. Historical references are provenance identifiers, not missing current runtime files. Old seals are unchanged. Local path strings are normalized; original and packaged hashes are recorded. Current required evidence is explicitly located in `retained-correspondence.json/current_evidence`.

The source archive retains its original copyright information. No new license is assigned by this supplement.
