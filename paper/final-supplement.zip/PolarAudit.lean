import Solutions
import Lean

/-! Audit-only bridges for the final manuscript. The fixed mathematical source
release is imported unchanged. These checks are compiled separately. -/

open J0RadialUniqueness

namespace FinalManuscriptAudit

theorem positivePolar_sector_norm (ρ θ : ℝ) (hρ : 0 < ρ)
    (hθ : 0 < θ ∧ θ < Real.pi / 4) :
    PrincipalSector ((ρ : ℂ) * Complex.exp (Complex.I * (θ : ℂ))) ∧
    ‖(ρ : ℂ) * Complex.exp (Complex.I * (θ : ℂ))‖ = ρ := by
  have hθπ : θ ∈ Set.Ioc (-Real.pi) Real.pi :=
    ⟨by linarith [hθ.1, Real.pi_pos], by linarith [hθ.2, Real.pi_pos]⟩
  have harg : (((ρ : ℂ) * Complex.exp (Complex.I * (θ : ℂ))).arg) = θ := by
    rw [mul_comm Complex.I (θ : ℂ), Complex.exp_ofReal_mul_I]
    have h := Complex.arg_mul_cos_add_sin_mul_I (r := ρ) (θ := θ) hρ hθπ
    simpa only [← Complex.ofReal_cos, ← Complex.ofReal_sin] using h
  constructor
  · apply (revision_principal_sector_arg_iff _).mpr
    simpa only [harg] using hθ
  · simp [abs_of_pos hρ]

theorem principalSector_iff_positivePolar (z : ℂ) :
    PrincipalSector z ↔ ∃ ρ θ : ℝ, 0 < ρ ∧ 0 < θ ∧ θ < Real.pi / 4 ∧
      z = (ρ : ℂ) * Complex.exp (Complex.I * (θ : ℂ)) := by
  constructor
  · intro hz
    have ha := (revision_principal_sector_arg_iff z).mp hz
    refine ⟨‖z‖, z.arg, norm_pos_iff.mpr (principalSector_ne_zero hz), ha.1, ha.2, ?_⟩
    rw [mul_comm Complex.I (z.arg : ℂ)]
    exact (Complex.norm_mul_exp_arg_mul_I z).symm
  · rintro ⟨ρ, θ, hρ, hlo, hhi, rfl⟩
    exact (positivePolar_sector_norm ρ θ hρ ⟨hlo, hhi⟩).1

theorem final_polar_proposition_5_1 (ρ θ : ℝ) (hρ : 0 < ρ)
    (hθ : 0 < θ ∧ θ < Real.pi / 4)
    (hJ : J0 ((ρ : ℂ) * Complex.exp (Complex.I * (θ : ℂ))) = 1) :
    let z := (ρ : ℂ) * Complex.exp (Complex.I * (θ : ℂ))
    (∀ τ : ℝ, 1 ≤ τ →
      DifferentiableAt ℝ (fun t : ℝ => Real.log ‖J0 ((t : ℂ) * z)‖) τ ∧
      (7 / 25 : ℝ) < τ * deriv (fun t : ℝ => Real.log ‖J0 ((t : ℂ) * z)‖) τ) ∧
    (∀ c : ℝ, 1 < c → Real.rpow c (7 / 25 : ℝ) < ‖J0 ((c : ℂ) * z)‖) := by
  exact paper_5_1 _ hJ (positivePolar_sector_norm ρ θ hρ hθ).1

theorem omitted_positive_radius_admits_zero :
    J0 (0 : ℂ) = 1 ∧
    (0 : ℂ) = (0 : ℂ) * Complex.exp (Complex.I * ((Real.pi / 8 : ℝ) : ℂ)) ∧
    (0 : ℝ) < Real.pi / 8 ∧ Real.pi / 8 < Real.pi / 4 ∧
    ¬ (Real.rpow 2 (7 / 25 : ℝ) < ‖J0 ((2 : ℂ) * (0 : ℂ))‖) := by
  refine ⟨by simp, by simp, by positivity, by linarith [Real.pi_pos], ?_⟩
  have h : 1 < Real.rpow 2 (7 / 25 : ℝ) := by
    rw [Real.rpow_eq_pow]
    exact Real.one_lt_rpow (by norm_num) (by norm_num)
  simpa only [mul_zero, J0_zero, norm_one] using (not_lt.mpr h.le)

theorem zero_ray_derivative :
    deriv (fun t : ℝ => Real.log ‖J0 ((t : ℂ) * (0 : ℂ))‖) 1 = 0 := by
  simp

theorem positive_radius_excludes_zero : ¬ ((0 : ℝ) > 0) := by norm_num

#print axioms positivePolar_sector_norm
#print axioms principalSector_iff_positivePolar
#print axioms final_polar_proposition_5_1
#print axioms omitted_positive_radius_admits_zero
#print axioms zero_ray_derivative
#print axioms positive_radius_excludes_zero

end FinalManuscriptAudit
