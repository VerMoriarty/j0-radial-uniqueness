"""Read-only verification of this supplement and its fixed Lean source checkout."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parent
ALLOWED = {"propext", "Classical.choice", "Quot.sound"}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(value, message):
    if not value:
        raise RuntimeError(message)


def read(name):
    return json.loads((ROOT / name).read_text())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--code-root", type=Path, required=True)
    parser.add_argument("--manuscript", type=Path)
    args = parser.parse_args()
    manifest = read("MANIFEST.json")
    for rel, expected in manifest.items():
        p = Path(rel)
        require(not p.is_absolute() and ".." not in p.parts, "Unsafe manifest path")
        require((ROOT / p).is_file() and not (ROOT / p).is_symlink(), "Missing or linked package file: " + rel)
        require(sha(ROOT / p) == expected, "Package hash mismatch: " + rel)
    actual = {str(p.relative_to(ROOT)) for p in ROOT.rglob("*") if p.is_file()}
    require(actual == set(manifest) | {"MANIFEST.json", "MANIFEST.sha256"}, "Package inventory differs from its manifest")
    require((ROOT / "MANIFEST.sha256").read_text().split()[0] == sha(ROOT / "MANIFEST.json"), "Manifest digest mismatch")
    binding = read("FINAL_MANUSCRIPT_ALIGNMENT.json")
    identity = read("code-identity.json")
    code = args.code_root.resolve()
    require(len(identity["files"]) == 193, "Incorrect fixed Lean inventory")
    for name, expected in identity["files"].items():
        p = Path(name)
        require(not p.is_absolute() and ".." not in p.parts, "Unsafe code path")
        require((code / p).is_file() and not (code / p).is_symlink() and sha(code / p) == expected,
                "Fixed Lean source mismatch: " + name)
    names = {str(p.relative_to(code)) for p in code.rglob("*.lean")
             if not any(part in {".lake", ".git", "CHECK_RUNS"} for part in p.relative_to(code).parts)}
    require(names == set(identity["files"]), "Additional or missing Lean source")
    env_check = read("current-environment-audit.json")
    require(sha(code / "SOURCE_MANIFEST.json") == env_check["source_manifest_sha256"], "Source manifest changed")
    for name, expected in json.loads((code / "SOURCE_MANIFEST.json").read_text())["files_sha256"].items():
        require(sha(code / name) == expected, "Fixed source/reproduction file changed: " + name)
    git_checked = (code / ".git").exists()
    if git_checked:
        require(subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=code, text=True).strip() == binding["fixed_code_commit"], "Wrong Git commit")
        require(not subprocess.check_output(["git", "status", "--porcelain"], cwd=code, text=True), "Code checkout is not clean")
    correspondence = read("retained-correspondence.json")
    require(len(correspondence["entries"]) == 118, "Wrong statement inventory")
    roots = set(correspondence["retained_unique_roots"])
    require(len(roots) == 248 and roots == set(read("current-root-catalog.json")), "Root catalog mismatch")
    require(roots == set(read("dependency_closures.json")), "Dependency closure inventory mismatch")
    definitions = read("evidence/fresh-definition-bodies.json")["definitions"]
    require(len(definitions) == 359, "Definition catalog mismatch")
    require(sha(ROOT / "evidence/fresh-definition-bodies.json") == read("definition-identity.json")["definition_catalog_sha256"], "Definition bodies changed")
    for name in correspondence["current_evidence"].values():
        require((ROOT / name).is_file(), "Missing required current evidence: " + name)
    targets = read("current-target-checks.json")
    require(len(targets["claims"]) == 16 and len(targets["support_targets"]) == 16, "Target inventory mismatch")
    for row in targets["claims"] + targets["support_targets"]:
        require(row["status"] == "closed" and row["type_matches"] and not row["unexpected_axioms"]
                and set(row["axioms"]) <= ALLOWED, "Recorded exact-target check failed")
    for entry in correspondence["entries"]:
        require(entry["coverage_status"] == "covered" and entry["lean_roots"], "Uncovered statement")
        for evidence in entry["local_evidence"]:
            p = code / evidence["source_file"]
            require(p.is_file() and sha(p) == evidence["source_file_sha256"], "Evidence source mismatch")
            excerpt = "\n".join(p.read_text().splitlines()[evidence["start_line"] - 1:evidence["end_line"]])
            require(excerpt == evidence["actual_source_text"], "Evidence excerpt mismatch")
    require(sha(ROOT / "PolarAudit.lean") == read("polar-kernel-result.json")["source_sha256"], "Polar bridge source changed")
    require(read("polar-kernel-result.json")["exit_code"] == 0, "Polar audit failed")
    if args.manuscript:
        require(sha(args.manuscript) == binding["manuscript_sha256"], "Manuscript hash mismatch")
        lines = args.manuscript.read_text().splitlines()
        for entry in correspondence["entries"]:
            excerpt = "\n".join(lines[entry["source_start_line"] - 1:entry["source_end_line"]])
            require(excerpt == entry["source_excerpt"], "Manuscript excerpt mismatch: " + entry["id"])
    print(json.dumps({"status": "passed_for_requested_checks", "package_hashes_verified": len(manifest),
        "fixed_Lean_sources_verified": 193, "git_commit_checked": git_checked,
        "statement_bindings_verified": 118, "root_types_available": 248,
        "definition_bodies_available": 359, "manuscript_source_verified": bool(args.manuscript),
        "kernel_replayed": False,
        "scope": "Read-only package/source/evidence integrity; live Lean replay uses the documented commands."}, indent=2))


if __name__ == "__main__":
    main()
